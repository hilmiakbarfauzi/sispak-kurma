<?php
$koneksi = mysqli_connect(
    "localhost",
    "root",
    "",
    "db_sispak_kurma" 
);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
